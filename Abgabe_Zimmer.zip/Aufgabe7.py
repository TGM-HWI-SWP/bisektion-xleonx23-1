import math
import matplotlib.pyplot as plt
import numpy as np

def plotter():
    class BaseSolver:
        def __init__(self, func_str: str) -> None:
            self.func_str = func_str

        def _evaluate(self, expression: str, x: float) -> float:
            try:
                return eval(expression, {"__builtins__": None}, {"x": x, "math": math})
            except Exception as error:
                raise ValueError(f"Fehler im Ausdruck: {error}")

    class BisectionSolver(BaseSolver):
        def solve(self, a: float, b: float, tol: float = 1e-7, max_iter: int = 1000):
            pass

    def visualize_bisection(func: str, a: float, b: float, iterations: int = 20):
        solver = BaseSolver(func)
        x_vals = []
        error_vals = []
        f = lambda x: solver._evaluate(func, x)

        for _ in range(iterations):
            c = (a + b) / 2
            x_vals.append(c)
            error_vals.append(abs(f(c)))

            if f(a) * f(c) < 0:
                b = c
            else:
                a = c

        plt.figure(figsize=(10, 8))
        plt.subplot(2, 1, 1)
        plt.plot(error_vals, marker='o')
        plt.yscale('log')
        plt.title("Fehler pro Iteration (logarithmisch)")
        plt.grid(True)

        plt.subplot(2, 1, 2)
        plt.plot(x_vals, marker='s', color='orange')
        plt.title("Annäherung an Lösung")
        plt.grid(True)

        plt.tight_layout()
        plt.show()

    visualize_bisection("x**2 - 25", 0, 50)

if __name__ == "__main__":
    plotter()